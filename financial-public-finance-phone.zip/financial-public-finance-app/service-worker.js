const CACHE_NAME = 'malia-omomia-shell-v3';
const COURSE_PDFS = [
  ')2025-2024(العامة المالية مقياس في العادية الدورة المتحان النموذجية اإلجابة.pdf',
  'الاجابة النموذجية لسنة الدراسية 2023 2024.pdf',
  'محاضرة ١ مدخل إلى المالية العامة (1).pdf',
  'محاضرة ٢ النفقات العامة.pdf',
  'محاضرة ٣ مدخل الإيرادات العامة.pdf',
  'محاضرة ٤ إيرادات الدومين.pdf',
  'محاضرة ٥ الرسوم.pdf',
  'محاضرة ٦ الضرائب .pdf',
  'محاضرة ٧ القروض العامة.pdf',
  'محاضرة ٨ ماهية الميزانية العامة.pdf'
].map((filename) => new URL(encodeURIComponent(filename), self.registration.scope).href);
const APP_FILES = [
  './',
  './index.html',
  './styles.css',
  './course-data.js',
  './teaching-content.js',
  './quiz-sources.js',
  './app.js',
  './manifest.webmanifest',
  './icons/app-icon.svg',
  './icons/app-icon-192.png',
  './icons/app-icon-512.png'
];

self.addEventListener('install', (event) => {
  event.waitUntil(
    caches.open(CACHE_NAME)
      .then((cache) => cache.addAll([...APP_FILES, ...COURSE_PDFS]))
      .then(() => self.skipWaiting())
  );
});

self.addEventListener('activate', (event) => {
  event.waitUntil(
    caches.keys()
      .then((keys) => Promise.all(keys
        .filter((key) => key.startsWith('malia-omomia-') && key !== CACHE_NAME)
        .map((key) => caches.delete(key))))
      .then(() => self.clients.claim())
  );
});

self.addEventListener('fetch', (event) => {
  const request = event.request;
  if (request.method !== 'GET') return;

  const requestUrl = new URL(request.url);
  if (requestUrl.origin !== self.location.origin) return;

  if (request.mode === 'navigate') {
    event.respondWith(
      caches.match(new URL('./index.html', self.registration.scope).href)
        .then((cached) => cached || fetch(request))
    );
    return;
  }

  event.respondWith(
    caches.match(request).then((cached) => {
      if (cached) return cached;
      return fetch(request).then((response) => {
        if (response && response.ok && response.type === 'basic') {
          const copy = response.clone();
          caches.open(CACHE_NAME).then((cache) => cache.put(request, copy));
        }
        return response;
      });
    })
  );
});
