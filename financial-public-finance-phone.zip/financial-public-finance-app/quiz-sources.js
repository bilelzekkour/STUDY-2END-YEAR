/* مواضع أسئلة الاختيار من متعدد: أرقام الصفحات هي صفحات ملف PDF الأصلي. */
window.QUIZ_SOURCES = {
  "intro-quiz-1": { section: "عناصر المالية العامة", page: 9, pages: "9" },
  "intro-quiz-2": { section: "الحاجات الإنسانية", page: 4, pages: "4" },
  "intro-quiz-3": { section: "تطور أشكال المالية العامة في ظل الدولة الحديثة", page: 20, pages: "20–21" },

  "spending-quiz-1": { section: "تعريف النفقة العامة وعناصرها", page: 4, pages: "4–5" },
  "spending-quiz-2": { section: "تقسيم النفقات بحسب الأثر الاقتصادي", page: 12, pages: "12" },
  "spending-quiz-3": { section: "قواعد الإنفاق العام", page: 23, pages: "23" },

  "revenue-quiz-1": { section: "التقسيم حسب معيار المصدر", page: 13, pages: "13" },
  "revenue-quiz-2": { section: "مصادر الإيرادات العامة", page: 5, pages: "5" },
  "revenue-quiz-3": { section: "التقسيم حسب معيار سلطة الحصول على الإيرادات", page: 15, pages: "15" },

  "domain-quiz-1": { section: "أقسام الدومين العام والخاص", page: 5, pages: "5–7" },
  "domain-quiz-2": { section: "أنواع الدومين الخاص وإيرادات الدومين المالي", page: 8, pages: "8 و12" },
  "domain-quiz-3": { section: "تقدير الثمن العام في سوق الاحتكار", page: 17, pages: "17" },

  "fees-quiz-1": { section: "تعريف الرسم وخصائصه", page: 4, pages: "4–5، 11" },
  "fees-quiz-2": { section: "الجبر المعنوي", page: 8, pages: "8" },
  "fees-quiz-3": { section: "الأساس القانوني لفرض الرسم", page: 14, pages: "14" },

  "taxes-quiz-1": { section: "تعريف الضريبة وخصائصها", page: 3, pages: "3–4" },
  "taxes-quiz-2": { section: "نظرية المنفعة والعقد الاجتماعي", page: 6, pages: "6" },
  "taxes-quiz-3": { section: "تحديد مبلغ الضريبة: الواقعة والوعاء والسعر", page: 19, pages: "19–21" },

  "loans-quiz-1": { section: "فرص ومخاطر القروض الداخلية والخارجية", page: 14, pages: "14" },
  "loans-quiz-2": { section: "انقضاء القرض العام", page: 26, pages: "26" },
  "loans-quiz-3": { section: "أوجه الاختلاف بين القرض والضريبة", page: 9, pages: "8–9" },

  "budget-quiz-1": { section: "التمييز بين الميزانية العامة والحساب الختامي", page: 12, pages: "12" },
  "budget-quiz-2": { section: "قاعدة عمومية الميزانية", page: 31, pages: "31" },
  "budget-quiz-3": { section: "الأهداف الاقتصادية للميزانية", page: 16, pages: "16" }
};
