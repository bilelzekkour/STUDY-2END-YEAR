(function () {
  'use strict';

  const DATA = window.STUDY_DATA;
  const main = document.getElementById('main-content');
  const STORAGE_KEY = 'madar-public-finance-progress-v1';

  const allCards = DATA.lessons.flatMap((lesson) => lesson.cards.map((card, index) => ({
    ...card,
    id: `${lesson.id}-card-${index + 1}`,
    lessonId: lesson.id,
    lessonTitle: lesson.title,
    lessonNumber: lesson.number
  })));
  const allQuestions = DATA.lessons.flatMap((lesson) => lesson.quiz.map((question, index) => {
    const id = `${lesson.id}-quiz-${index + 1}`;
    const source = (window.QUIZ_SOURCES || {})[id] || {};
    return {
      ...question,
      id,
      lessonId: lesson.id,
      lessonTitle: lesson.title,
      lessonNumber: lesson.number,
      sourceSection: source.section || 'راجع موضع السؤال في المحاضرة الأصلية',
      sourcePage: Number.isInteger(source.page) ? source.page : null,
      sourcePages: source.pages || String(question.ref || '').replace(/^ص\s*/, '') || 'غير محدد'
    };
  }));

  function defaultState() {
    return { completedLessons: [], masteredCards: [], quizAttempts: 0, bestScore: null, lastLessonId: null };
  }

  function loadState() {
    try {
      const saved = JSON.parse(localStorage.getItem(STORAGE_KEY) || 'null');
      if (!saved || typeof saved !== 'object') return defaultState();
      return {
        completedLessons: Array.isArray(saved.completedLessons) ? saved.completedLessons.filter((id) => DATA.lessons.some((lesson) => lesson.id === id)) : [],
        masteredCards: Array.isArray(saved.masteredCards) ? saved.masteredCards.filter((id) => allCards.some((card) => card.id === id)) : [],
        quizAttempts: Number.isFinite(saved.quizAttempts) ? Math.max(0, saved.quizAttempts) : 0,
        bestScore: Number.isFinite(saved.bestScore) ? saved.bestScore : null,
        lastLessonId: DATA.lessons.some((lesson) => lesson.id === saved.lastLessonId) ? saved.lastLessonId : null
      };
    } catch (error) {
      return defaultState();
    }
  }

  let state = loadState();
  let currentView = 'home';
  let activeLessonId = null;
  let activeExamId = null;
  let cardSession = null;
  let cardSummary = null;
  let quizSession = null;
  let quizSelection = new Set(DATA.lessons.map((lesson) => lesson.id));
  let quizCountChoice = '8';
  let teachingStepIndex = 0;
  let navigationHistory = [];
  let installPromptEvent = null;

  function saveState() {
    try { localStorage.setItem(STORAGE_KEY, JSON.stringify(state)); } catch (error) { /* file:// privacy settings may disable storage */ }
    updateSidebar();
  }

  function digits(value) {
    return String(value).replace(/[\u0660-\u0669\u06f0-\u06f9]/g, (digit) => {
      const code = digit.charCodeAt(0);
      return String(code >= 0x06f0 ? code - 0x06f0 : code - 0x0660);
    });
  }

  function escapeHtml(value) {
    return String(value == null ? '' : value).replace(/[&<>"']/g, (character) => ({
      '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;'
    })[character]);
  }

  function pdfUrl(filename) {
    return encodeURIComponent(filename);
  }

  function pdfLink(filename, label) {
    return `<a class="btn btn-soft btn-small" href="${pdfUrl(filename)}" target="_blank" rel="noopener">${escapeHtml(label || 'افتح ملف PDF')} <span aria-hidden="true">↗</span></a>`;
  }

  function findLesson(id) { return DATA.lessons.find((lesson) => lesson.id === id); }
  function findExam(id) { return DATA.exams.find((exam) => exam.id === id); }
  function isDone(id) { return state.completedLessons.includes(id); }
  function progressPercent() { return Math.round((state.completedLessons.length / DATA.lessons.length) * 100); }

  function updateSidebar() {
    const percent = progressPercent();
    const label = document.getElementById('side-progress-label');
    const bar = document.getElementById('side-progress-bar');
    const note = document.getElementById('side-progress-note');
    if (label) label.textContent = `${digits(percent)}٪`;
    if (bar) bar.style.width = `${percent}%`;
    if (note) note.textContent = state.completedLessons.length
      ? `أنجزت ${digits(state.completedLessons.length)} من ${digits(DATA.lessons.length)} محاضرات`
      : 'ابدأ بمحاضرة واحدة اليوم';
  }

  function getRouteSnapshot() {
    const searchInput = document.getElementById('search-input');
    return {
      view: currentView,
      lessonId: activeLessonId,
      examId: activeExamId,
      query: searchInput ? searchInput.value : '',
      quizSelection: [...quizSelection],
      quizCountChoice,
      teachingStepIndex,
      scrollY: window.scrollY || 0
    };
  }

  function rememberNavigation() {
    const snapshot = getRouteSnapshot();
    const previous = navigationHistory[navigationHistory.length - 1];
    if (previous && previous.view === snapshot.view && previous.lessonId === snapshot.lessonId && previous.examId === snapshot.examId && previous.query === snapshot.query) return;
    navigationHistory.push(snapshot);
    if (navigationHistory.length > 40) navigationHistory.shift();
  }

  function setView(view) {
    if (currentView !== view || activeLessonId || activeExamId) rememberNavigation();
    currentView = view;
    activeLessonId = null;
    activeExamId = null;
    teachingStepIndex = 0;
    render();
    window.scrollTo({ top: 0, behavior: 'smooth' });
  }

  function goBack() {
    if (!navigationHistory.length || !confirmLeaveExam()) return;
    const previous = navigationHistory.pop();
    if (currentView === 'cards' && cardSession) { cardSession = null; cardSummary = null; }
    quizSession = null;
    currentView = previous.view || 'home';
    activeLessonId = previous.lessonId || null;
    activeExamId = previous.examId || null;
    teachingStepIndex = previous.teachingStepIndex || 0;
    quizSelection = new Set(previous.quizSelection || DATA.lessons.map((lesson) => lesson.id));
    quizCountChoice = previous.quizCountChoice || '8';
    const searchInput = document.getElementById('search-input');
    if (searchInput && previous.query != null) searchInput.value = previous.query;
    render();
    window.scrollTo({ top: previous.scrollY || 0, behavior: 'smooth' });
  }

  function updateAppBackButton() {
    const button = document.getElementById('app-back-button');
    if (button) button.disabled = navigationHistory.length === 0;
  }

  function moveTeachingStep(targetIndex) {
    const teaching = (window.TEACHING_DATA || {})[activeLessonId];
    if (!teaching || !teaching.steps.length) return;
    teachingStepIndex = Math.max(0, Math.min(teaching.steps.length - 1, targetIndex));
    render();
    const teachingSection = document.querySelector('.teaching-section');
    if (teachingSection) teachingSection.scrollIntoView({ behavior: 'smooth', block: 'start' });
  }

  function render() {
    document.querySelectorAll('.nav-item').forEach((item) => {
      item.classList.toggle('active', item.dataset.view === currentView);
    });
    if (currentView === 'home') main.innerHTML = renderHome();
    else if (currentView === 'lessons') main.innerHTML = activeLessonId ? renderLessonDetail(findLesson(activeLessonId)) : renderLessons();
    else if (currentView === 'cards') main.innerHTML = renderCards();
    else if (currentView === 'quiz') main.innerHTML = renderQuiz();
    else if (currentView === 'exams') main.innerHTML = activeExamId ? renderExamDetail(findExam(activeExamId)) : renderExams();
    else if (currentView === 'search') main.innerHTML = renderSearch(document.getElementById('search-input').value.trim());
    else main.innerHTML = renderHome();
    updateSidebar();
    updateAppBackButton();
    if (currentView === 'quiz' && !quizSession) updateQuizSelectionUI();
  }

  function lessonRow(lesson) {
    const complete = isDone(lesson.id);
    return `<button class="lesson-row" type="button" data-open-lesson="${lesson.id}">
      <span class="lesson-number">${lesson.number}</span>
      <span class="lesson-row-copy"><strong>${escapeHtml(lesson.title)}</strong><small>${escapeHtml(lesson.short)}</small></span>
      <span class="lesson-state ${complete ? 'done' : ''}"><i class="state-dot" aria-hidden="true"></i>${complete ? 'مكتملة' : 'ابدأ'}</span>
    </button>`;
  }

  function renderHome() {
    const completed = state.completedLessons.length;
    const continueLesson = findLesson(state.lastLessonId) || DATA.lessons[0];
    const percent = progressPercent();
    return `<section class="hero" aria-labelledby="hero-title">
      <div class="hero-copy">
        <span class="eyebrow">مساحة مراجعة شخصية · ثماني محاضرات</span>
        <h1 id="hero-title">المالية العامة،<br>خطوة أوضح كل يوم.</h1>
        <p>ملخصات من محاضراتك، بطاقات للاسترجاع النشط، وأسئلة على نمط النماذج. ادرس بهدوء — من دون حساب أو اتصال بخدمة خارجية.</p>
        <div class="hero-actions">
          <button class="btn btn-primary" type="button" data-action="continue">تابع التعلّم <span aria-hidden="true">←</span></button>
          <button class="btn btn-light" type="button" data-view="quiz">ابدأ اختبارًا قصيرًا</button>
          <button class="btn btn-light install-app-button" type="button" data-action="install-app">ثبّت كتطبيق</button>
        </div>
      </div>
      <div class="hero-visual" aria-hidden="true">
        <div class="hero-orbit"></div>
        <div class="hero-seal"><span>مراجعة</span><strong>م</strong><span>مالية عمومية</span></div>
        <span class="hero-float one">فهم · تذكّر · تطبيق</span>
        <span class="hero-float two">تقدّمك ${digits(percent)}٪</span>
      </div>
    </section>

    <section class="stats-grid" aria-label="ملخص المقرر">
      <div class="stat-card"><span class="stat-icon" aria-hidden="true">▦</span><span><strong>${digits(DATA.lessons.length)}</strong><small>محاضرات مرتبة</small></span></div>
      <div class="stat-card"><span class="stat-icon" aria-hidden="true">◇</span><span><strong>${digits(allCards.length)}</strong><small>بطاقة استرجاع</small></span></div>
      <div class="stat-card"><span class="stat-icon" aria-hidden="true">◉</span><span><strong>${digits(allQuestions.length)}</strong><small>سؤال تدريبي</small></span></div>
    </section>

    <div class="content-grid">
      <div class="content-stack">
        <section class="section-block">
          <div class="section-heading"><div><span class="eyebrow">خريطة المقياس</span><h2>من المفاهيم إلى الميزانية</h2><p>ابدأ بالترتيب، أو اختر المحور الذي تحتاج إلى مراجعته.</p></div><button class="text-button" type="button" data-view="lessons">ادخل إلى قسم التدريس ←</button></div>
          <div class="lesson-list">${DATA.lessons.slice(0, 4).map(lessonRow).join('')}</div>
        </section>
        <section class="section-block">
          <div class="section-heading"><div><span class="eyebrow">تدرّب بذكاء</span><h2>ما الذي يتكرر في النماذج؟</h2></div><button class="text-button" type="button" data-view="exams">تحليل النماذج ←</button></div>
          <div class="panel exam-teaser">${DATA.exams.map((exam) => `<div class="exam-teaser-row"><span><strong>${escapeHtml(exam.title)}</strong><small>${escapeHtml(exam.shape)}</small></span><span class="exam-year-pill">${escapeHtml(exam.points)}</span></div>`).join('')}</div>
        </section>
      </div>
      <aside class="content-stack side-extras">
        <section class="continue-card">
          <span class="eyebrow">${completed ? `تقدّمك ${digits(completed)} من ${digits(DATA.lessons.length)}` : 'اقتراح البداية'}</span>
          <h3>${completed ? 'واصل من حيث توقفت' : 'ابدأ من أساس المقياس'}</h3>
          <p>${escapeHtml(continueLesson.number)} · ${escapeHtml(continueLesson.title)}<br>${escapeHtml(continueLesson.short)}</p>
          <button class="btn btn-green btn-small" type="button" data-action="continue">افتح المحاضرة <span aria-hidden="true">←</span></button>
        </section>
        <section class="panel">
          <div class="section-heading"><div><span class="eyebrow">جلسة قصيرة</span><h2>طريقة مراجعة مقترحة</h2></div></div>
          <div class="rhythm-list">
            <div class="rhythm-item"><span class="rhythm-time">15 د</span><span>اقرأ الملخص وحدد الفكرة الأساسية.</span></div>
            <div class="rhythm-item"><span class="rhythm-time">10 د</span><span>استرجع التعريفات ببطاقات المراجعة.</span></div>
            <div class="rhythm-item"><span class="rhythm-time">10 د</span><span>حلّ أسئلة قصيرة دون الرجوع للملاحظات.</span></div>
          </div>
        </section>
        <section class="panel">
          <div class="section-heading"><div><span class="eyebrow">حفظ على جهازك</span><h2>متابعة تقدّمك</h2></div><strong class="pill">${digits(percent)}٪</strong></div>
          <div class="progress-track"><span style="width:${percent}%"></span></div>
          <p class="page-lead">أكملت ${digits(completed)} من ${digits(DATA.lessons.length)} محاضرات. حالة البطاقات ونتيجتك تُحفظ في هذا المتصفح.</p>
          <button class="text-button" type="button" data-action="reset-progress" style="margin-top:10px">إعادة ضبط التقدّم</button>
        </section>
      </aside>
    </div>`;
  }

  function renderLessons() {
    return `<div class="page-heading"><div><span class="eyebrow">شرح وتدريس</span><h1 class="page-title">قسم التدريس</h1><p class="page-lead">اختر محاضرة لشرحها خطوة بخطوة مع أمثلة، نقاط مهمة، ملخص ملوّن وخريطة ذهنية.</p></div>
      <span class="pill">${digits(state.completedLessons.length)} / ${digits(DATA.lessons.length)} مكتملة</span></div>
      <div class="lesson-grid">${DATA.lessons.map((lesson) => `<button class="lesson-card" type="button" data-open-lesson="${lesson.id}">
        <div class="lesson-card-top"><span class="lesson-number">${lesson.number}</span><span class="pill">${escapeHtml(lesson.label)}</span></div>
        <h2>${escapeHtml(lesson.title)}</h2><p>${escapeHtml(lesson.short)}</p>
        <div class="lesson-card-bottom"><span>${escapeHtml(lesson.pages)} من الملف الأصلي</span><span class="${isDone(lesson.id) ? 'done-label' : ''}">${isDone(lesson.id) ? '✓ تمت المراجعة' : 'افتح المحور ←'}</span></div>
      </button>`).join('')}</div>`;
  }

  function renderLessonDetail(lesson) {
    if (!lesson) return renderLessons();
    state.lastLessonId = lesson.id;
    saveState();
    const completed = isDone(lesson.id);
    const teaching = (window.TEACHING_DATA || {})[lesson.id] || {
      opening: lesson.summary,
      openingSource: `المحاضرة ${lesson.number} · ملف المحاضرة الأصلي`,
      steps: lesson.points.map((text, index) => ({ title: `${index + 1}. الفكرة`, text, example: 'راجع المثال المرتبط بهذه الفكرة في ملف المحاضرة.', source: `المحاضرة ${lesson.number} · ${lesson.pages}` })),
      important: lesson.examHint,
      importantSource: `المحاضرة ${lesson.number} · ${lesson.pages}`,
      summary: [{ label: 'الخلاصة', text: lesson.summary, tone: 'mint' }],
      mindmap: { center: lesson.title, branches: [{ title: 'المفاهيم', items: lesson.terms.map((term) => term.term) }] }
    };
    const stepCount = teaching.steps.length;
    teachingStepIndex = Math.max(0, Math.min(stepCount - 1, teachingStepIndex));
    const currentStep = teaching.steps[teachingStepIndex];
    const progress = Math.round(((teachingStepIndex + 1) / stepCount) * 100);
    const summaryHtml = teaching.summary.map((tile) => `<article class="summary-tile tone-${escapeHtml(tile.tone)}"><span>${escapeHtml(tile.label)}</span><strong>${escapeHtml(tile.text)}</strong></article>`).join('');
    const mindmapHtml = teaching.mindmap.branches.map((branch) => `<article class="mindmap-branch"><strong class="mindmap-node">${escapeHtml(branch.title)}</strong><div class="mindmap-children">${branch.items.map((item) => `<span>${escapeHtml(item)}</span>`).join('')}</div></article>`).join('');
    const stepPathHtml = teaching.steps.map((step, index) => `<button class="teaching-path-step ${index === teachingStepIndex ? 'active' : ''} ${index < teachingStepIndex ? 'visited' : ''}" type="button" data-action="set-teaching-step" data-step-index="${index}" ${index === teachingStepIndex ? 'aria-current="step"' : ''}><span>${digits(index + 1)}</span><small>${escapeHtml(step.title.replace(/^\d+\.\s*/, ''))}</small></button>${index < stepCount - 1 ? '<span class="teaching-path-arrow" aria-hidden="true">←</span>' : ''}`).join('');
    const nextStepControl = teachingStepIndex + 1 < stepCount
      ? `<button class="btn btn-green" type="button" data-action="next-teaching-step">الخطوة التالية ←</button>`
      : `<button class="btn btn-green" type="button" data-action="go-to-recap">انتقل إلى الملخص ↓</button>`;
    return `<button class="back-button" type="button" data-action="back-lessons">→ العودة إلى قسم التدريس</button>
      <div class="lesson-detail-head"><span class="lesson-number">${lesson.number}</span><span><span class="eyebrow">شرح مبسّط · ${escapeHtml(lesson.pages)}</span><h1 class="lesson-detail-title">${escapeHtml(lesson.title)}</h1><p class="lesson-detail-short">${escapeHtml(lesson.short)}</p></span></div>
      <section class="teaching-intro"><span class="teaching-intro-icon" aria-hidden="true">✦</span><div><strong>الفكرة العامة للمحاضرة</strong><p>${escapeHtml(teaching.opening)}</p><small class="teaching-source-ref">${escapeHtml(teaching.openingSource || '')}</small></div></section>
      <section class="teaching-section"><div class="section-heading"><div><span class="eyebrow">مسار تدريجي</span><h2>شرح المحاضرة مع أمثلة</h2><p>انتقل من خطوة إلى التالية؛ يمكنك الرجوع أو فتح أي خطوة من المسار.</p></div></div>
        <nav class="teaching-path" aria-label="تسلسل خطوات المحاضرة">${stepPathHtml}</nav>
        <div class="teaching-progress-heading"><strong>الخطوة ${digits(teachingStepIndex + 1)} من ${digits(stepCount)}</strong><span>${digits(progress)}٪</span></div><div class="progress-track teaching-step-progress"><span style="width:${progress}%"></span></div>
        <div class="teaching-steps"><article class="teaching-step" aria-live="polite"><div class="teaching-step-head"><span class="teaching-step-number">${digits(teachingStepIndex + 1)}</span><h3>${escapeHtml(currentStep.title.replace(/^\d+\.\s*/, ''))}</h3></div><p>${escapeHtml(currentStep.text)}</p><div class="teaching-example"><span>مثال من المنهاج</span><p>${escapeHtml(currentStep.example)}</p><small class="teaching-source-ref">${escapeHtml(currentStep.source)}</small></div>${currentStep.quizNote ? `<aside class="teaching-quiz-note" role="note"><span class="teaching-quiz-note-icon" aria-hidden="true">◉</span><div><strong>معلومة يراجعها «اختبر نفسك»</strong><p>${escapeHtml(currentStep.quizNote)}</p></div></aside>` : ''}${currentStep.bridge ? `<div class="teaching-step-bridge"><strong>${teachingStepIndex + 1 < stepCount ? 'الربط بالخطوة التالية' : 'خلاصة ترابط المحاضرة'}</strong><p>${escapeHtml(currentStep.bridge)}</p></div>` : ''}</article></div>
        <div class="teaching-step-nav"><button class="btn btn-outline" type="button" data-action="previous-teaching-step" ${teachingStepIndex === 0 ? 'disabled' : ''}>→ الخطوة السابقة</button><span>تسلسل المحاضرة: ${digits(teachingStepIndex + 1)} / ${digits(stepCount)}</span>${nextStepControl}</div>
      </section>
      <div class="teaching-support-grid">
        <section class="panel"><div class="section-heading"><div><span class="eyebrow">مصطلحات أساسية</span><h2>تأكد أنك تميّز بينها</h2></div></div><div class="term-list">${lesson.terms.map((term) => `<div class="term-item"><strong>${escapeHtml(term.term)}</strong><p>${escapeHtml(term.meaning)}</p></div>`).join('')}</div></section>
        <aside class="teaching-callout"><span class="callout-mark" aria-hidden="true">!</span><div><strong>معلومة مهمة من المحاضرة</strong><p>${escapeHtml(teaching.important)}</p><small class="teaching-source-ref">${escapeHtml(teaching.importantSource || '')}</small><div class="callout-exam"><b>صلة بالنموذج المرفوع:</b> ${escapeHtml(lesson.examHint)}</div></div></aside>
      </div>
      <section class="panel teaching-source-panel"><div><span class="eyebrow">المصدر الأصلي</span><h2>ارجع إلى صفحات المحاضرة</h2><p class="page-lead">أرقام الصفحات أدناه تشير إلى ملف PDF المرفوع.</p></div><div class="source-line"><span>${escapeHtml(lesson.pages)}</span>${pdfLink(lesson.pdf, 'افتح ملف المحاضرة')}</div></section>
      <section class="teaching-recap" id="teaching-recap"><div class="section-heading"><div><span class="eyebrow">قبل أن تنتقل للمحاضرة التالية</span><h2>ملخص ملوّن وخريطة ذهنية</h2><p>استرجع الكلمات المفتاحية، ثم حاول إعادة رسم الخريطة من الذاكرة.</p></div></div>
        <div class="colored-summary">${summaryHtml}</div>
        <div class="mindmap-card"><span class="mindmap-caption">خريطة ذهنية صغيرة</span><div class="mindmap-center">${escapeHtml(teaching.mindmap.center)}</div><div class="mindmap-branches">${mindmapHtml}</div></div>
      </section>
      <section class="panel next-steps-panel"><div class="section-heading"><div><span class="eyebrow">تثبيت التعلّم</span><h2>ماذا تفعل الآن؟</h2></div><span class="pill">${completed ? 'تمت مراجعتها' : 'اختر خطوة'}</span></div><div class="detail-actions"><button class="btn btn-green" type="button" data-start-cards="lesson" data-lesson-id="${lesson.id}">راجع بطاقات المحور</button><button class="btn btn-outline" type="button" data-start-quiz="${lesson.id}">اختبر فهمك</button><button class="btn ${completed ? 'btn-soft' : 'btn-outline'}" type="button" data-action="toggle-complete" data-lesson-id="${lesson.id}">${completed ? '✓ أزل علامة الإكمال' : 'علّم المحور كمكتمل'}</button></div></section>`;
  }

  function renderCards() {
    if (cardSession) return renderCardSession();
    if (cardSummary) {
      const summary = cardSummary;
      const allDone = summary.total === 0;
      return `<div class="page-heading"><div><span class="eyebrow">مراجعة نشطة</span><h1 class="page-title">${allDone ? 'كل البطاقات متقنة!' : 'أحسنت، أنهيت هذه الجولة'}</h1><p class="page-lead">يمكنك مراجعة الإجابات في قسم التدريس أو بدء جولة أخرى.</p></div></div>
        <section class="panel" style="max-width:700px"><div class="result-score">${digits(summary.mastered)}<small>بطاقة متقنة</small></div><p class="page-lead">${allDone ? 'لا توجد بطاقات تحتاج إلى مراجعة الآن.' : `راجعت ${digits(summary.total)} بطاقة في هذه الجولة.`}</p><div class="detail-actions">${allDone ? '' : '<button class="btn btn-green" type="button" data-start-cards="review">راجع البطاقات غير المتقنة</button>'}<button class="btn btn-outline" type="button" data-start-cards="all">ابدأ جولة كاملة</button><button class="btn btn-outline" type="button" data-action="clear-card-summary">عودة إلى خيارات البطاقات</button></div></section>`;
    }
    const notMastered = allCards.filter((card) => !state.masteredCards.includes(card.id)).length;
    return `<div class="page-heading"><div><span class="eyebrow">استرجاع نشط</span><h1 class="page-title">بطاقات المراجعة</h1><p class="page-lead">اقرأ السؤال، حاول الإجابة من ذاكرتك، ثم اكشف الإجابة وقيّم نفسك.</p></div><span class="pill">${digits(state.masteredCards.length)} / ${digits(allCards.length)} متقنة</span></div>
      <div class="cards-start-grid">
        <section class="practice-choice"><span class="choice-icon" aria-hidden="true">◇</span><h2>جولة كاملة</h2><p>مجموعة مختلطة من جميع المحاضرات. علّم البطاقة متقنة عندما تستطيع استرجاع جوابها.</p><button class="btn btn-green" type="button" data-start-cards="all">ابدأ ${digits(allCards.length)} بطاقة</button></section>
        <section class="practice-choice"><span class="choice-icon" aria-hidden="true">↻</span><h2>راجع ما لم تتقنه</h2><p>ركّز على البطاقات التي لم تضع عليها علامة «متقنة» بعد.</p><button class="btn btn-outline" type="button" data-start-cards="review" ${notMastered === 0 ? 'disabled' : ''}>ابدأ ${digits(notMastered)} بطاقة</button></section>
      </div>
      <div class="source-warning" style="max-width:820px">تُحفظ علامة إتقان البطاقة في متصفحك على هذا الجهاز. لا تُرسل إجاباتك إلى أي مكان.</div>`;
  }

  function renderCardSession() {
    if (!cardSession || !cardSession.cards.length) return renderCards();
    const card = cardSession.cards[cardSession.index];
    const mastered = state.masteredCards.includes(card.id);
    const sessionTitle = cardSession.lessonId ? findLesson(cardSession.lessonId).title : (cardSession.mode === 'review' ? 'البطاقات غير المتقنة' : 'جولة كاملة');
    return `<div class="flashcard-shell">
      <div class="flashcard-toolbar"><button class="back-button" style="margin:0" type="button" data-action="leave-cards">→ إنهاء الجولة</button><span>${escapeHtml(sessionTitle)}</span><span>${digits(cardSession.index + 1)} / ${digits(cardSession.cards.length)}</span></div>
      <div class="progress-track"><span style="width:${Math.round(((cardSession.index + 1) / cardSession.cards.length) * 100)}%"></span></div>
      <section class="flashcard" aria-live="polite"><span class="flashcard-label">${escapeHtml(card.lessonNumber)} · ${escapeHtml(card.lessonTitle)}</span><h1 class="flashcard-question">${escapeHtml(card.q)}</h1>
        ${cardSession.revealed ? `<div class="flashcard-answer">${escapeHtml(card.a)}</div><span class="flashcard-ref">${escapeHtml(card.ref)} · من ملف المحاضرة</span>` : `<p class="page-lead">حاول أن تستحضر الجواب قبل كشفه.</p>`}
        <div class="flashcard-actions">${cardSession.revealed
          ? `<button class="btn btn-soft" type="button" data-card-next="no">أحتاج إلى مراجعتها</button><button class="btn btn-green" type="button" data-card-next="yes">${mastered ? 'متقنة ✓ · التالي' : 'أتقنتها · التالي'}</button>`
          : `<button class="btn btn-green" type="button" data-action="reveal-card">اكشف الإجابة</button>`}</div>
      </section>
      <p class="page-lead" style="margin:12px auto 0;text-align:center">${digits(state.masteredCards.length)} بطاقة متقنة من ${digits(allCards.length)}</p>
    </div>`;
  }

  function quizAvailabilitySummary(lessonCount, questionCount) {
    return `المحاضرات المحددة: ${digits(lessonCount)} · الأسئلة المتاحة: ${digits(questionCount)}`;
  }

  function renderQuiz() {
    if (quizSession) return quizSession.finished ? renderQuizResult() : renderQuizQuestion();
    const best = state.bestScore == null ? 'لم تدخل اختبارًا بعد' : `أفضل نتيجة سابقة: ${digits(state.bestScore)} إجابات صحيحة`;
    const selectedCount = quizSelection.size;
    const availableCount = allQuestions.filter((question) => quizSelection.has(question.lessonId)).length;
    return `<div class="page-heading"><div><span class="eyebrow">منهاجك فقط · مع موضع كل معلومة</span><h1 class="page-title">اختبر نفسك</h1><p class="page-lead">اختر المحاضرات، ثم تدرب مع التصحيح الفوري أو أنشئ امتحانًا تجريبيًا يجمع بينها.</p></div><span class="pill">${escapeHtml(best)}</span></div>
      <section class="panel quiz-panel">
        <div class="section-heading"><div><span class="eyebrow">1 · اختر المحاضرات</span><h2>محتوى الاختبار</h2><p>يمكنك تحديد محاضرة واحدة للتدريب أو محاضرتين فأكثر للامتحان التجريبي.</p></div></div>
        <div class="quiz-topic-toolbar"><strong id="quiz-selection-status">${quizAvailabilitySummary(selectedCount, availableCount)}</strong><div><button class="text-button" type="button" data-action="select-all-topics">تحديد الكل</button><span class="toolbar-separator">·</span><button class="text-button" type="button" data-action="clear-topics">مسح التحديد</button></div></div>
        <div class="quiz-topic-grid">${DATA.lessons.map((lesson) => `<label class="quiz-topic-option"><input type="checkbox" data-quiz-topic="${lesson.id}" ${quizSelection.has(lesson.id) ? 'checked' : ''}><span class="topic-number">${lesson.number}</span><span class="topic-copy"><strong>${escapeHtml(lesson.title)}</strong><small>${digits(lesson.quiz.length)} أسئلة · ${escapeHtml(lesson.pages)}</small></span></label>`).join('')}</div>
        <p class="selection-help" id="quiz-selection-help">يخلط الامتحان التجريبي الأسئلة ويضمن سؤالًا واحدًا على الأقل من كل محاضرة محددة؛ لذا قد يزيد العدد الفعلي إذا اخترت محاضرات أكثر من العدد المطلوب.</p>
        <div class="quiz-controls quiz-exam-controls"><div class="form-field"><label for="quiz-count">عدد الأسئلة المطلوب</label><select id="quiz-count" aria-describedby="quiz-selection-help"><option value="6" ${quizCountChoice === '6' ? 'selected' : ''}>6 أسئلة</option><option value="8" ${quizCountChoice === '8' ? 'selected' : ''}>8 أسئلة</option><option value="12" ${quizCountChoice === '12' ? 'selected' : ''}>12 سؤالًا</option><option value="all" ${quizCountChoice === 'all' ? 'selected' : ''}>كل الأسئلة المتاحة</option></select></div>
          <div class="detail-actions quiz-start-actions"><button class="btn btn-outline" id="start-topic-practice" type="button" data-action="start-selected-quiz" ${selectedCount < 1 ? 'disabled' : ''}>تدريب مع تصحيح فوري</button><button class="btn btn-green" id="start-mock-exam" type="button" data-action="start-mock-exam" ${selectedCount < 2 ? 'disabled' : ''}>إنشاء امتحان تجريبي · محاضرتان فأكثر</button></div>
        </div>
      </section>
      <div class="source-warning" style="max-width:920px">كل سؤال مرتبط بعنوان المحاضرة والقسم ورقم صفحة PDF. في التدريب يظهر المرجع بعد إجابتك؛ وفي الامتحان التجريبي تظهر الإجابات والمراجع بعد إنهائه.</div>`;
  }

  function questionSourceHtml(item) {
    const lesson = findLesson(item.lessonId);
    const pageIsKnown = Number.isInteger(item.sourcePage);
    const href = pageIsKnown ? `${pdfUrl(lesson.pdf)}#page=${item.sourcePage}` : pdfUrl(lesson.pdf);
    const pageText = item.sourcePages && item.sourcePages !== 'غير محدد' ? `PDF ص ${escapeHtml(item.sourcePages)}` : 'رقم الصفحة غير محدد';
    const linkText = pageIsKnown ? `افتح الصفحة ${digits(item.sourcePage)} ↗` : 'افتح ملف المحاضرة ↗';
    return `<div class="question-source"><span class="question-source-icon" aria-hidden="true">⌖</span><div class="question-source-copy"><strong>موضع المعلومة في المنهاج</strong><span>المحاضرة ${escapeHtml(item.lessonNumber)} · ${escapeHtml(item.lessonTitle)}</span><small>${escapeHtml(item.sourceSection)} · ${pageText}</small></div><a href="${href}" target="_blank" rel="noopener">${linkText}</a></div>`;
  }

  function renderQuizQuestion() {
    const session = quizSession;
    const item = session.questions[session.index];
    const selected = session.selected;
    const examMode = session.mode === 'exam';
    const letters = ['أ', 'ب', 'ج', 'د'];
    const options = item.options.map((option, index) => {
      let status = '';
      if (session.answered && !examMode && index === item.correct) status = 'correct';
      else if (session.answered && !examMode && index === selected) status = 'incorrect';
      return `<button class="answer-option ${status}" type="button" data-answer-index="${index}" ${session.answered ? 'disabled' : ''}><span class="answer-letter">${letters[index] || digits(index + 1)}</span><span>${escapeHtml(option)}</span></button>`;
    }).join('');
    const feedback = !session.answered ? '' : examMode
      ? `<div class="quiz-feedback recorded"><strong>تم تسجيل إجابتك.</strong><br>سيظهر التصحيح وموضع المعلومة بعد إنهاء الامتحان التجريبي.</div>`
      : `<div class="quiz-feedback ${selected === item.correct ? 'correct' : 'incorrect'}"><strong>${selected === item.correct ? 'إجابة صحيحة' : 'راجع هذه الفكرة'}</strong><br>${escapeHtml(item.why)}</div>${questionSourceHtml(item)}`;
    const footerText = examMode ? 'لن يظهر التصحيح حتى تسلّم الإجابات.' : `الإجابات الصحيحة: ${digits(session.score)}`;
    const nextLabel = session.index + 1 === session.questions.length ? (examMode ? 'إنهاء الامتحان' : 'عرض النتيجة') : 'السؤال التالي ←';
    return `<div class="page-heading"><div><span class="eyebrow">${examMode ? 'امتحان تجريبي' : 'تدريب'} · المحاضرة ${escapeHtml(item.lessonNumber)} · ${escapeHtml(item.lessonTitle)}</span><h1 class="page-title">سؤال ${digits(session.index + 1)}</h1></div><button class="text-button" type="button" data-action="leave-quiz">${examMode ? 'إلغاء الامتحان' : 'إنهاء التدريب'}</button></div>
      <div class="progress-track" style="max-width:920px"><span style="width:${Math.round(((session.index + (session.answered ? 1 : 0)) / session.questions.length) * 100)}%"></span></div>
      <section class="question-card"><div class="question-meta"><span>${digits(session.index + 1)} من ${digits(session.questions.length)} أسئلة</span><span>${examMode ? 'تُكشف المراجع عند التسليم' : 'أجب ثم راجع المصدر'}</span></div><h2 class="question-title">${escapeHtml(item.q)}</h2><div class="answer-options">${options}</div>
        ${feedback}
        <div class="quiz-footer"><span class="page-lead">${footerText}</span>${session.answered ? `<button class="btn btn-green btn-small" type="button" data-action="next-question">${nextLabel}</button>` : ''}</div>
      </section>`;
  }

  function renderQuizResult() {
    const session = quizSession;
    const total = session.questions.length;
    const score = session.score;
    const pct = Math.round((score / total) * 100);
    const isExam = session.mode === 'exam';
    const note = pct >= 80 ? 'إتقان جيد للمفاهيم المختارة؛ راجع مواضعها في المحاضرات.' : (pct >= 50 ? 'راجع الأسئلة التي أخطأت فيها ثم أعد الاختبار.' : 'ارجع إلى الشروح المحددة في المراجع ثم حاول مرة أخرى.');
    const review = isExam ? `<section class="quiz-review"><div class="section-heading"><div><span class="eyebrow">مراجعة موثقة</span><h2>إجاباتك ومواضعها في المحاضرات</h2><p>افتح كل سؤال لمعرفة الإجابة الصحيحة وموضعها في ملف المقياس.</p></div></div>${session.questions.map((item, index) => {
      const answer = session.answers[index];
      const correct = answer === item.correct;
      return `<details class="quiz-review-item"><summary><strong>سؤال ${digits(index + 1)} · المحاضرة ${escapeHtml(item.lessonNumber)}</strong><span class="${correct ? 'review-correct' : 'review-incorrect'}">${correct ? 'صحيح' : 'يحتاج مراجعة'}　＋</span></summary><div class="quiz-review-content"><p><b>السؤال:</b> ${escapeHtml(item.q)}</p><p><b>إجابتك:</b> ${escapeHtml(item.options[answer])}</p><p><b>الإجابة الصحيحة:</b> ${escapeHtml(item.options[item.correct])}</p><p class="review-explanation">${escapeHtml(item.why)}</p>${questionSourceHtml(item)}</div></details>`;
    }).join('')}</section>` : '';
    const selectedLessons = [...new Set(session.questions.map((question) => question.lessonId))].map((id) => findLesson(id));
    const coverageText = selectedLessons.length === 1 ? 'محاضرة واحدة ممثلة' : `${digits(selectedLessons.length)} محاضرات ممثلة`;
    return `<div class="page-heading"><div><span class="eyebrow">${isExam ? 'انتهى الامتحان التجريبي' : 'انتهى التدريب'}</span><h1 class="page-title">${isExam ? 'نتيجة الامتحان' : 'نتيجتك'}</h1><p class="page-lead">${escapeHtml(note)}</p></div></div>
      <section class="panel quiz-panel"><div class="result-score">${digits(score)}<small>من ${digits(total)}</small></div><p class="page-lead">${digits(pct)}٪ إجابات صحيحة · ${coverageText}</p><div class="detail-actions"><button class="btn btn-green" type="button" data-action="restart-quiz">اختبار جديد</button><button class="btn btn-outline" type="button" data-view="lessons">ارجع إلى التدريس</button></div></section>${review}`;
  }

  function renderExams() {
    return `<div class="page-heading"><div><span class="eyebrow">مراجعة واقعية</span><h1 class="page-title">نماذج الامتحان</h1><p class="page-lead">حلّل نمط الأسئلة، جرّب الإجابة أولًا، ثم اكشف مخططًا مختصرًا للحل.</p></div><span class="pill">${digits(DATA.exams.length)} نموذجان مرفوعان</span></div>
      <div class="exam-grid">${DATA.exams.map((exam) => `<article class="exam-card"><div class="exam-card-top"><span class="pill">الدورة العادية</span><span class="exam-year-pill">${escapeHtml(exam.points)}</span></div><h2>${escapeHtml(exam.title)}</h2><p>${escapeHtml(exam.shape)}</p><div class="exam-card-bottom"><span class="page-lead">مبني على ملف الإجابة النموذجية</span><button class="btn btn-green btn-small" type="button" data-open-exam="${exam.id}">ابدأ المراجعة ←</button></div></article>`).join('')}</div>
      <div class="source-warning">النماذج المرفوعة موسومة بالإجابة النموذجية؛ التمرين هنا يدرّب على المحاور وطريقة بناء الإجابة. راجع ملف PDF الأصلي عند الحاجة إلى النص الكامل.</div>`;
  }

  function renderExamDetail(exam) {
    if (!exam) return renderExams();
    return `<button class="back-button" type="button" data-action="back-exams">→ العودة إلى النماذج</button>
      <div class="exam-detail-top"><div><span class="eyebrow">تحليل نموذج · ${escapeHtml(exam.year)}</span><h1>${escapeHtml(exam.title)}</h1><p>${escapeHtml(exam.shape)}</p></div>${pdfLink(exam.pdf, 'فتح ملف الإجابة الأصلي')}</div>
      <section class="panel" style="margin-bottom:16px"><div class="section-heading"><div><span class="eyebrow">طريقة التدريب</span><h2>حاول قبل أن تكشف الإجابة</h2></div><span class="pill">${escapeHtml(exam.points)}</span></div><p class="page-lead">اقرأ المطلوب، اكتب إجابتك في ورقة أو من الذاكرة، ثم افتح كل سؤال لمقارنة عناصر إجابتك بالمخطط.</p></section>
      <div class="exam-question-list">${exam.questions.map((question, index) => `<details class="exam-question"><summary><strong>${escapeHtml(question.title)}</strong><span>${escapeHtml(question.score)}　＋</span></summary><div class="exam-question-content"><p><strong>المطلوب:</strong> ${escapeHtml(question.prompt)}</p><div class="exam-answer-title">مخطط الإجابة</div><ul>${question.outline.map((line) => `<li>${escapeHtml(line)}</li>`).join('')}</ul><p class="exam-tip"><strong>تلميح للمراجعة:</strong> ${escapeHtml(question.tip)}</p></div></details>`).join('')}</div>
      <div class="source-line" style="max-width:900px"><span>المرجع: نموذج الإجابة ${escapeHtml(exam.year)} · الصفحات 1–2</span>${pdfLink(exam.pdf, 'افتح نسخة PDF')}</div>`;
  }

  function normalizeText(text) {
    return String(text || '').toLowerCase()
      .replace(/[\u064B-\u065F\u0670]/g, '')
      .replace(/[أإآ]/g, 'ا').replace(/ى/g, 'ي').replace(/ة/g, 'ه')
      .replace(/[ًٌٍَُِّْـ]/g, '').replace(/[^\p{L}\p{N}\s]/gu, ' ').replace(/\s+/g, ' ').trim();
  }

  function renderSearch(query) {
    const needle = normalizeText(query);
    if (!needle) return `<div class="page-heading"><div><span class="eyebrow">بحث في محتوى المقرر</span><h1 class="page-title">ابحث عن مفهوم</h1><p class="page-lead">اكتب كلمة أو عبارة في مربع البحث أعلى الصفحة.</p></div></div><div class="empty-state">جرّب مثلًا: <strong>الميزانية · الجبر المعنوي · القرض الخارجي</strong></div>`;
    const results = [];
    DATA.lessons.forEach((lesson) => {
      const teaching = (window.TEACHING_DATA || {})[lesson.id];
      const teachingText = teaching ? [teaching.opening, teaching.important, teaching.steps.map((step) => `${step.title} ${step.text} ${step.example}`).join(' '), teaching.summary.map((tile) => `${tile.label} ${tile.text}`).join(' ')].join(' ') : '';
      const corpus = [lesson.title, lesson.short, lesson.summary, lesson.points.join(' '), lesson.terms.map((term) => `${term.term} ${term.meaning}`).join(' '), teachingText].join(' ');
      if (normalizeText(corpus).includes(needle)) {
        const termMatch = lesson.terms.find((term) => normalizeText(`${term.term} ${term.meaning}`).includes(needle));
        results.push({ title: termMatch ? termMatch.term : lesson.title, subtitle: termMatch ? termMatch.meaning : lesson.short, kind: 'محاضرة', action: 'lesson', id: lesson.id });
      }
    });
    DATA.exams.forEach((exam) => {
      const corpus = [exam.title, exam.shape, exam.questions.map((question) => `${question.prompt} ${question.outline.join(' ')}`).join(' ')].join(' ');
      if (normalizeText(corpus).includes(needle)) results.push({ title: exam.title, subtitle: exam.shape, kind: 'نموذج امتحان', action: 'exam', id: exam.id });
    });
    const safeQuery = escapeHtml(query);
    return `<div class="page-heading"><div><span class="eyebrow">نتائج البحث</span><h1 class="page-title">بحث عن «${safeQuery}»</h1><p class="page-lead">${digits(results.length)} نتيجة في الشروح والأمثلة والتعاريف ونماذج الإجابة.</p></div></div>
      ${results.length ? `<div class="search-results">${results.map((result) => `<button class="search-result" type="button" ${result.action === 'lesson' ? `data-open-lesson="${result.id}"` : `data-open-exam="${result.id}"`}><span><strong>${escapeHtml(result.title)}</strong><small>${escapeHtml(result.subtitle)}</small></span><span class="search-kind">${escapeHtml(result.kind)}　←</span></button>`).join('')}</div>` : `<div class="empty-state"><strong>لم نعثر على نتيجة بهذه العبارة.</strong>جرّب كلمة أقصر أو مرادفًا من عنوان المحاضرة.</div>`}`;
  }

  function shuffle(array) {
    const copy = array.slice();
    for (let i = copy.length - 1; i > 0; i -= 1) {
      const j = Math.floor(Math.random() * (i + 1));
      [copy[i], copy[j]] = [copy[j], copy[i]];
    }
    return copy;
  }

  function startCards(mode, lessonId) {
    let pool = allCards.slice();
    if (mode === 'review') pool = pool.filter((card) => !state.masteredCards.includes(card.id));
    if (mode === 'lesson' && lessonId) pool = pool.filter((card) => card.lessonId === lessonId);
    rememberNavigation();
    if (!pool.length) {
      cardSummary = { total: 0, mastered: state.masteredCards.length };
      cardSession = null;
      currentView = 'cards';
      render();
      return;
    }
    cardSummary = null;
    cardSession = { cards: shuffle(pool), index: 0, revealed: false, mode, lessonId: lessonId || null };
    currentView = 'cards';
    activeLessonId = null;
    render();
  }

  function finishCard(markMastered) {
    const card = cardSession.cards[cardSession.index];
    if (markMastered && !state.masteredCards.includes(card.id)) {
      state.masteredCards.push(card.id);
      saveState();
    }
    cardSession.index += 1;
    cardSession.revealed = false;
    if (cardSession.index >= cardSession.cards.length) {
      cardSummary = { total: cardSession.cards.length, mastered: state.masteredCards.length };
      cardSession = null;
    }
    render();
  }

  function updateQuizSelectionUI() {
    const checkboxes = Array.from(document.querySelectorAll('[data-quiz-topic]'));
    if (!checkboxes.length) return;
    quizSelection = new Set(checkboxes.filter((checkbox) => checkbox.checked).map((checkbox) => checkbox.dataset.quizTopic));
    const available = allQuestions.filter((question) => quizSelection.has(question.lessonId)).length;
    const status = document.getElementById('quiz-selection-status');
    const practiceButton = document.getElementById('start-topic-practice');
    const examButton = document.getElementById('start-mock-exam');
    const countSelect = document.getElementById('quiz-count');
    if (status) status.textContent = quizAvailabilitySummary(quizSelection.size, available);
    if (practiceButton) practiceButton.disabled = quizSelection.size < 1;
    if (examButton) examButton.disabled = quizSelection.size < 2;
    if (countSelect) quizCountChoice = countSelect.value;
  }

  function startQuiz(mode, lessonIds) {
    const selectedIds = [...new Set((lessonIds || []).filter((id) => findLesson(id)))];
    if (!selectedIds.length) return;
    if (mode === 'exam' && selectedIds.length < 2) {
      window.alert('للامتحان التجريبي اختر محاضرتين على الأقل.');
      return;
    }
    rememberNavigation();
    quizSelection = new Set(selectedIds);
    const countSelect = document.getElementById('quiz-count');
    if (countSelect) quizCountChoice = countSelect.value;
    const pool = allQuestions.filter((question) => quizSelection.has(question.lessonId));
    if (!pool.length) return;
    const requested = quizCountChoice === 'all' ? pool.length : Math.max(1, Number(quizCountChoice) || 8);
    let questions;
    if (mode === 'exam') {
      const targetCount = Math.min(pool.length, Math.max(requested, selectedIds.length));
      const representativeQuestions = selectedIds.map((id) => shuffle(pool.filter((question) => question.lessonId === id))[0]).filter(Boolean);
      const chosenIds = new Set(representativeQuestions.map((question) => question.id));
      const remaining = shuffle(pool.filter((question) => !chosenIds.has(question.id)));
      questions = shuffle([...representativeQuestions, ...remaining.slice(0, targetCount - representativeQuestions.length)]);
    } else {
      questions = shuffle(pool).slice(0, Math.min(requested, pool.length));
    }
    quizSession = { questions, index: 0, score: 0, selected: null, answered: false, finished: false, mode, answers: [] };
    currentView = 'quiz';
    activeLessonId = null;
    render();
  }

  function answerQuiz(index) {
    if (!quizSession || quizSession.answered) return;
    const question = quizSession.questions[quizSession.index];
    quizSession.selected = index;
    quizSession.answers[quizSession.index] = index;
    quizSession.answered = true;
    if (index === question.correct) quizSession.score += 1;
    render();
  }

  function nextQuizQuestion() {
    if (!quizSession) return;
    if (quizSession.index + 1 >= quizSession.questions.length) {
      quizSession.finished = true;
      state.quizAttempts += 1;
      if (state.bestScore == null || quizSession.score > state.bestScore) state.bestScore = quizSession.score;
      saveState();
    } else {
      quizSession.index += 1;
      quizSession.selected = null;
      quizSession.answered = false;
    }
    render();
  }

  function confirmLeaveExam() {
    if (!quizSession || quizSession.finished || quizSession.mode !== 'exam') return true;
    return window.confirm('هل تريد مغادرة الامتحان التجريبي؟ لن تُحفظ الإجابات الحالية.');
  }

  function handleAction(action, element) {
    if (action === 'app-back') {
      goBack();
    } else if (action === 'install-app') {
      if (installPromptEvent) {
        const installEvent = installPromptEvent;
        installPromptEvent = null;
        installEvent.prompt();
        if (installEvent.userChoice && typeof installEvent.userChoice.then === 'function') installEvent.userChoice.then(() => {});
      } else {
        const dialog = document.getElementById('install-dialog');
        if (dialog && typeof dialog.showModal === 'function') dialog.showModal();
        else window.alert('على Android افتح قائمة المتصفح واختر تثبيت التطبيق. على iPhone اختر مشاركة ثم إضافة إلى الشاشة الرئيسية.');
      }
    } else if (action === 'close-install') {
      const dialog = document.getElementById('install-dialog');
      if (dialog && typeof dialog.close === 'function') dialog.close();
    } else if (action === 'continue') {
      rememberNavigation();
      const lesson = findLesson(state.lastLessonId) || DATA.lessons[0];
      currentView = 'lessons'; activeLessonId = lesson.id; teachingStepIndex = 0; state.lastLessonId = lesson.id; saveState(); render();
    } else if (action === 'back-lessons') {
      const previous = navigationHistory[navigationHistory.length - 1];
      if (previous && previous.view === 'lessons' && !previous.lessonId) goBack();
      else { activeLessonId = null; currentView = 'lessons'; teachingStepIndex = 0; render(); }
    } else if (action === 'previous-teaching-step') {
      moveTeachingStep(teachingStepIndex - 1);
    } else if (action === 'next-teaching-step') {
      moveTeachingStep(teachingStepIndex + 1);
    } else if (action === 'set-teaching-step') {
      moveTeachingStep(Number(element.dataset.stepIndex));
    } else if (action === 'go-to-recap') {
      const recap = document.getElementById('teaching-recap');
      if (recap) recap.scrollIntoView({ behavior: 'smooth', block: 'start' });
    } else if (action === 'toggle-complete') {
      const id = element.dataset.lessonId;
      state.completedLessons = isDone(id) ? state.completedLessons.filter((item) => item !== id) : [...state.completedLessons, id];
      saveState(); render();
    } else if (action === 'reveal-card') {
      if (cardSession) { cardSession.revealed = true; render(); }
    } else if (action === 'leave-cards') {
      cardSession = null; cardSummary = null; render();
    } else if (action === 'clear-card-summary') {
      cardSummary = null; render();
    } else if (action === 'leave-quiz') {
      if (confirmLeaveExam()) { quizSession = null; render(); }
    } else if (action === 'select-all-topics') {
      document.querySelectorAll('[data-quiz-topic]').forEach((checkbox) => { checkbox.checked = true; });
      updateQuizSelectionUI();
    } else if (action === 'clear-topics') {
      document.querySelectorAll('[data-quiz-topic]').forEach((checkbox) => { checkbox.checked = false; });
      updateQuizSelectionUI();
    } else if (action === 'start-selected-quiz') {
      startQuiz('practice', [...quizSelection]);
    } else if (action === 'start-mock-exam') {
      startQuiz('exam', [...quizSelection]);
    } else if (action === 'next-question') {
      nextQuizQuestion();
    } else if (action === 'restart-quiz') {
      quizSession = null; render();
    } else if (action === 'back-exams') {
      const previous = navigationHistory[navigationHistory.length - 1];
      if (previous && previous.view === 'exams' && !previous.examId) goBack();
      else { activeExamId = null; currentView = 'exams'; render(); }
    } else if (action === 'reset-progress') {
      if (window.confirm('هل تريد مسح تقدّم المحاضرات والبطاقات ونتيجة الاختبارات من هذا المتصفح؟')) {
        state = defaultState(); cardSession = null; cardSummary = null; quizSession = null; navigationHistory = []; teachingStepIndex = 0; saveState(); currentView = 'home'; render();
      }
    }
  }

  document.addEventListener('click', (event) => {
    const viewButton = event.target.closest('[data-view]');
    if (viewButton) {
      if (!confirmLeaveExam()) return;
      event.preventDefault();
      quizSession = null;
      setView(viewButton.dataset.view);
      return;
    }
    const openLesson = event.target.closest('[data-open-lesson]');
    if (openLesson) {
      rememberNavigation();
      activeLessonId = openLesson.dataset.openLesson;
      currentView = 'lessons';
      teachingStepIndex = 0;
      const lesson = findLesson(activeLessonId);
      if (lesson) { state.lastLessonId = lesson.id; saveState(); }
      render(); window.scrollTo({ top: 0, behavior: 'smooth' }); return;
    }
    const openExam = event.target.closest('[data-open-exam]');
    if (openExam) { rememberNavigation(); activeExamId = openExam.dataset.openExam; currentView = 'exams'; render(); window.scrollTo({ top: 0, behavior: 'smooth' }); return; }
    const startCardButton = event.target.closest('[data-start-cards]');
    if (startCardButton) { quizSession = null; startCards(startCardButton.dataset.startCards, startCardButton.dataset.lessonId || null); return; }
    const startQuizButton = event.target.closest('[data-start-quiz]');
    if (startQuizButton) { startQuiz('practice', [startQuizButton.dataset.startQuiz]); return; }
    const answerButton = event.target.closest('[data-answer-index]');
    if (answerButton) { answerQuiz(Number(answerButton.dataset.answerIndex)); return; }
    const nextCardButton = event.target.closest('[data-card-next]');
    if (nextCardButton) { finishCard(nextCardButton.dataset.cardNext === 'yes'); return; }
    const actionButton = event.target.closest('[data-action]');
    if (actionButton) { handleAction(actionButton.dataset.action, actionButton); }
  });

  document.addEventListener('change', (event) => {
    const topic = event.target.closest('[data-quiz-topic]');
    if (topic) updateQuizSelectionUI();
    if (event.target.id === 'quiz-count') quizCountChoice = event.target.value;
  });

  document.getElementById('search-form').addEventListener('submit', (event) => {
    if (!confirmLeaveExam()) return;
    event.preventDefault();
    rememberNavigation();
    quizSession = null;
    currentView = 'search'; activeLessonId = null; activeExamId = null;
    render(); window.scrollTo({ top: 0, behavior: 'smooth' });
  });

  if (typeof window.addEventListener === 'function') {
    window.addEventListener('beforeinstallprompt', (event) => {
      event.preventDefault();
      installPromptEvent = event;
    });
    window.addEventListener('appinstalled', () => { installPromptEvent = null; });
  }
  if (window.navigator && window.navigator.serviceWorker && window.location && window.location.protocol !== 'file:') {
    window.navigator.serviceWorker.register('./service-worker.js').catch(() => {});
  }

  render();
})();
